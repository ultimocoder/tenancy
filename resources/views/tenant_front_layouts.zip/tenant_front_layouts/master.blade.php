@include('front_layouts.header')

@yield('main-content')

