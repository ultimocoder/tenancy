<div class="footer">
    <div>© 2024 copy Tenancy right all rights reserved.</div>
    <div class="links">
        <a href="#">License</a>
        <a href="#">Terms of Use</a>
    </div>
</div>